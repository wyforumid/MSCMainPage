module.exports = function(name,type,value){
	this.name = name;
	this.type = type;
	this.value = value;

	return this;
}